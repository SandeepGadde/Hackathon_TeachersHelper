package com.example.teachershelper;

import java.util.ArrayList;



import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.TextView;

public class ShowListAdapter extends ArrayAdapter<SearchHelper>{
	ArrayList<SearchHelper> sh;
	static int st[];//selected indexes, can use to pull url from static sh in MainActivity
	static String selectedURL;
	public ShowListAdapter(ShowResults showResults, int listrow,int textid,
			ArrayList<SearchHelper> sh) {
		// TODO Auto-generated constructor stub
		super(ShowResults.ctx,R.layout.listrow,R.id.docname,sh);
		this.sh = sh;
		st = new int[sh.size()];
		for(int i=0;i<st.length;i++)
			st[i]=0;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return sh.size();
	}

	@Override
	public SearchHelper getItem(int position) {
		// TODO Auto-generated method stub
		return sh.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		View v = convertView;
		if (v == null) {
			LayoutInflater inflater = (LayoutInflater) ShowResults.ctx
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			v = inflater.inflate(R.layout.listrow, null);
		}	
		String docId = sh.get(position).getDocId();
		//if (docId != null) {
			final TextView textView = (TextView) v
					.findViewById(R.id.docname);
			 CheckBox cb = (CheckBox)v.findViewById(R.id.cb);
			textView.setText(sh.get(position).getDocTitle());
		if(st[position]==1)
			cb.setChecked(true);
		else
			cb.setChecked(false);
		textView.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Log.d("Clicked","Yes"+position);
				selectedURL = sh.get(position).getDocURL();
				(ShowResults.ctx).startActivity(new Intent(ShowResults.ctx,ShowWeb.class));
			}
		});
		cb.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(((CheckBox)v).isChecked())
				{
					st[position]=1;
					Log.d("Position Checked",position+"|"+MainActivity.sh.get(position).getDocURL());
				}
				else
				{
					st[position]=0;
					Log.d("Position UNChecked",position+"|"+MainActivity.sh.get(position).getDocURL());
				}
			}
		});
		
	//}
		return v;
	}

}
