package com.example.teachershelper;

import java.util.List;

import android.content.Context;
import android.widget.ArrayAdapter;

public class ShowSavedLessonAdapter  extends ArrayAdapter<String>{

	public ShowSavedLessonAdapter(Context context, int resource,
			int textViewResourceId, List<String> objects) {
		super(context, resource, textViewResourceId, objects);
		// TODO Auto-generated constructor stub
	}

}
