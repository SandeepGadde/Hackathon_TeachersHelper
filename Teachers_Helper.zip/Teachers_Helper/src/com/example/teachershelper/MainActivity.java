package com.example.teachershelper;

import java.util.ArrayList;



import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity {
	static Context ctx;
	ListView lv1,lv2;
	String st[] = new String[]{"abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc","abc"};
    ImageButton settings;
    static int[] setting={1,0,0};
    static ArrayList<String> tokens = new ArrayList<String>();
    Button start;
    static ArrayAdapter<String> adapter;
ArrayAdapter<String> recent;
    static ArrayList<SearchHelper> sh,shgoogle,shyoutube;
    static String keyword;
    ImageView viewSavedLessons;
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);
        getWindow().setSoftInputMode(
        	      WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        ctx = this;
        //lv1 = (ListView)findViewById(R.id.list1);
        settings= (ImageButton)findViewById(R.id.settings);
        start = (Button)findViewById(R.id.start);
        lv2 = (ListView)findViewById(R.id.list2);
        viewSavedLessons = (ImageView)findViewById(R.id.viewsavedlesson);
        //lv1.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,st));
        recent = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,tokens);
        lv2.setAdapter(recent);
    	settings.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(MainActivity.this,Settings.class));
			}});
    	 adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, tokens);
        final android.widget.AutoCompleteTextView textView = (android.widget.AutoCompleteTextView) findViewById(R.id.edit);
        textView.setAdapter(adapter);
        viewSavedLessons.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(MainActivity.this,ShowSavedLessons.class));
			}
		});
        start.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				adapter.add(textView.getText().toString());
				recent.add(textView.getText().toString());
				keyword = textView.getText().toString();
				new StartAsyncTask().execute("http://sandbox.learningregistry.org/slice?any_tags="+textView.getText().toString());
				Log.d("URL","http://sandbox.learningregistry.org/slice?any_tags="+textView.getText().toString());
			}
		});
        lv2.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				textView.setText(recent.getItem(arg2));
			}
		});
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
    public static void showResults(ArrayList<SearchHelper> sh,ArrayList<SearchHelper> shgoogle,ArrayList<SearchHelper> shyoutube)
    {
    	Log.d("size",String.valueOf(sh.size()));
    	if(setting[0]==1)
    	{
    		MainActivity.sh = sh;
    		if(setting[1]==1)
    		{
    	    		if(shgoogle.size()>0)
    	        	{
    	        		MainActivity.shgoogle = shgoogle;
    	        		for(int i=0;i<shgoogle.size();i++)
    	        		{
    	        			MainActivity.sh.add(shgoogle.get(i));
    	        		}
    	        	}
    	    		
    	    		if(setting[2]==1 && shyoutube.size()>0)
    	    		{
    	    			MainActivity.shyoutube = shyoutube;
    	    			for(int i=0;i<shyoutube.size();i++)
    	        		{
    	        			MainActivity.sh.add(shyoutube.get(i));
    	        		}
    	    			
    	    		}
    	    		(MainActivity.ctx).startActivity(new Intent(MainActivity.ctx,ShowResults.class));
    		}
    		else
    		{
    			if(sh.size()>0)
    			{
    				if(setting[2]==1 && shyoutube.size()>0)
    	    		{
    	    			MainActivity.shyoutube = shyoutube;
    	    			for(int i=0;i<shyoutube.size();i++)
    	        		{
    	    				Log.d("Adding Here",shyoutube.get(i).getDocTitle());
    	        			MainActivity.sh.add(shyoutube.get(i));
    	        		}
    	    			
    	    		}
    				(MainActivity.ctx).startActivity(new Intent(MainActivity.ctx,ShowResults.class));
	    		}
		    	else
		    		Toast.makeText(MainActivity.ctx, "No Records found..", Toast.LENGTH_LONG).show();
    		}
    	}
    	else if(setting[0]==0)
    	{
    		MainActivity.sh=new ArrayList<SearchHelper>();
    		if(setting[1]==1)
    		{
    	    		
    	    		if(shgoogle.size()>0)
    	        	{
    	        		MainActivity.shgoogle = shgoogle;
    	        		for(int i=0;i<shgoogle.size();i++)
    	        		{
    	        			MainActivity.sh.add(shgoogle.get(i));
    	        		}
    	        	}
    	    		if(setting[2]==1 && shyoutube.size()>0)
    	    		{
    	    			MainActivity.shyoutube = shyoutube;
    	    			for(int i=0;i<shyoutube.size();i++)
    	        		{
    	        			MainActivity.sh.add(shyoutube.get(i));
    	        		}
    	    		}
    	    		(MainActivity.ctx).startActivity(new Intent(MainActivity.ctx,ShowResults.class));
    	    	
    		}
    		else
    		{
    			if(setting[2]==1 && shyoutube.size()>0)
	    		{
	    			MainActivity.shyoutube = shyoutube;
	    			MainActivity.sh=new ArrayList<SearchHelper>();
	    			for(int i=0;i<shyoutube.size();i++)
	        		{
	        			MainActivity.sh.add(shyoutube.get(i));
	        		}
	    			(MainActivity.ctx).startActivity(new Intent(MainActivity.ctx,ShowResults.class));
	    			
	    		}
    		}
    	}
    		
    	
    }
    public void onDestroy()
    {
    	super.onDestroy();
    	MainActivity.adapter = null;
    	MainActivity.sh = null;
    	MainActivity.tokens = null;
    	MainActivity.setting = null;
    }
}
