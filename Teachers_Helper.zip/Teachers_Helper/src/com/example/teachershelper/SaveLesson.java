package com.example.teachershelper;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class SaveLesson extends Activity {
	WebView webview;
	private static final String TAG = "Main";
    private ProgressDialog progressBar = null;
    Button save;
    static final String logTag = "ActivitySwipeDetector";
    static final int MIN_DISTANCE = 100;
    private float downX, downY, upX, upY;
    int indexes[];
    ArrayList<SearchHelper> ar = new ArrayList<SearchHelper>();
    int j=0;
    TextView swipeText;
    TextView title,resTitle;
    static Context ctx;
    EditText desc;
    static DBAdapter db;
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.savelesson);
		title = (TextView)findViewById(R.id.title);
		title.setText(LessonPlan.lessonText.toUpperCase());
		resTitle = (TextView)findViewById(R.id.resTitle);
		indexes = ShowListAdapter.st;
		desc = (EditText)findViewById(R.id.desc);
		ctx = this;
		for(int i=0;i<indexes.length;i++)
		{
			Log.d("Index Values:","|"+indexes[i]);
			if(indexes[i]==1)
			{
				ar.add(MainActivity.sh.get(i));
			Log.d("heree",MainActivity.sh.get(i).getDocURL());
			}
			else
				Log.d("heree",MainActivity.sh.get(i).getDocURL());
		}
		save = (Button)findViewById(R.id.save);
		webview = (WebView)findViewById(R.id.webView2);
		swipeText = (TextView)findViewById(R.id.swipetext);
		WebSettings settings = webview.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setPluginsEnabled(true);
        settings.setSupportMultipleWindows(true);
        settings.setSupportZoom(false);
        save.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//Log.d("Assam","samasdi");
				 db = new DBAdapter( ctx ); 
				db.open();
				db.insertLesson(LessonPlan.lessonText,desc.getText().toString());
				
				
				for(int k=0;k<ar.size();k++)
				{
					db.insertContent(LessonPlan.lessonText, ar.get(k).getDocTitle(), ar.get(k).getDocURL());
					
				}
				ArrayList mylist = (ArrayList) db.getLessonList();
				for(int i=0;i<mylist.size();i++)
					Log.d("mylist value "+i,(String) mylist.get(i));
				//db.inse
			}
		});
        //settings.setAppCacheEnabled(true);
        
        
        webview.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
        webview.setWebChromeClient(new WebChromeClient());
        webview.setAlwaysDrawnWithCacheEnabled(true);
        
        final AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        progressBar = ProgressDialog.show(this, "", "Loading...     ");
        webview.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Log.i(TAG, "Processing webview url click...");	                
                view.loadUrl(url);
                return false;
            }
            
            public void onPageFinished(WebView view, String url) {
            	//Log.d("onPageStarted original",view.getOriginalUrl());
            	Log.d("onPageStarted",url);
                if (progressBar.isShowing()) {
                    progressBar.dismiss();
                }
                
            }
            
            public void onPageStarted(WebView view, String url, Bitmap favicon)
            {
            	//Log.d("onPageStarted original",view.getOriginalUrl());
            	Log.d("onPageStarted",url);
            	if(!progressBar.isShowing())
            		progressBar.show();
            }
            
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {	                	                
                alertDialog.setTitle("Error");
                alertDialog.setMessage(description);
                alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        return;
                    }
                });
                alertDialog.show();
            }
        });    
        webview.loadUrl(ar.get(j).getDocURL());
        resTitle.setText(ar.get(j).getDocTitle().toUpperCase());
        swipeText.setOnTouchListener(new OnTouchListener() {
			public boolean onTouch(View v, MotionEvent event) {
	            switch (event.getAction()) {
	            case MotionEvent.ACTION_DOWN: {
	                downX = event.getX();
	                downY = event.getY();
	                return true;
	            }
	            case MotionEvent.ACTION_UP: {
	                upX = event.getX();
	                upY = event.getY();

	                float deltaX = downX - upX;
	                float deltaY = downY - upY;

	                // swipe horizontal?
	                if (Math.abs(deltaX) > MIN_DISTANCE) {
	                    // left or right
	                    if (deltaX < 0) {
	                    	Log.i(logTag, "LeftToRightSwipe!"+deltaX+"|"+deltaY);
	                    	if(j>0)
	                    	{
	                    		j-=1;
	                    		Log.d("URL",ar.get(j).getDocURL());
	                    		webview.loadUrl(ar.get(j).getDocURL());
	                    		resTitle.setText(ar.get(j).getDocTitle().toUpperCase());
	                    	}
	                    }
	                    if (deltaX > 0) {
	                    	Log.i(logTag, "RightToLeftSwipe!"+deltaX+"|"+deltaY);
	                    	if(j<ar.size()-1)
	                    	{
	                    		j+=1;
	                    		Log.d("URL",ar.get(j).getDocURL());
	                    		webview.loadUrl(ar.get(j).getDocURL());
	                    		resTitle.setText(ar.get(j).getDocTitle().toUpperCase());
	                    	}
	                        return true;
	                    }
	                }
	                else {
	                    Log.i(logTag, "Swipe was only " + Math.abs(deltaX)
	                            + " long, need at least " + MIN_DISTANCE);
	                }
	                return true;
	            }
	            }
	            return false;
	        }
		});		
	}
}
