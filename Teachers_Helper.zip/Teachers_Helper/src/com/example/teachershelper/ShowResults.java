package com.example.teachershelper;

import java.util.ArrayList;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ShowResults extends Activity {
	ListView lv;
	static Context ctx;
	Button save;
	TextView title;
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.showresults);
		
		ctx = this;
		save = (Button)findViewById(R.id.save);
		lv = (ListView)findViewById(R.id.list);
		title = (TextView)findViewById(R.id.title);
		ShowListAdapter adapter;
		/*if(MainActivity.setting[1]==1)
			adapter = new ShowListAdapter(this,
		        R.layout.listrow,R.id.docname, MainActivity.sh,MainActivity.shgoogle);
		else*/
			adapter = new ShowListAdapter(this,
			        R.layout.listrow,R.id.docname, MainActivity.sh);
		lv.setAdapter(adapter);
		title.setText("Results for Keyword:"+MainActivity.keyword.toUpperCase());
		save.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				int temp = 0;
				for(int i=0;i<ShowListAdapter.st.length;i++)
				{
					if(ShowListAdapter.st[i]==1)
					{
						temp=1;
						//startActivity(new Intent(ShowResults.this,LessonPlan.class));
						break;
					}
				}
				if(temp==1)
					startActivity(new Intent(ShowResults.this,LessonPlan.class));
				else
					Toast.makeText(ctx, "Select atleast one lesson", Toast.LENGTH_LONG).show();
			}
		});
		    
	}
}
