package com.example.teachershelper;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

public class LessonPlan extends Activity {
	Button go;
	EditText lessonName;
	static String lessonText;
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.lessonplan);
		go = (Button)findViewById(R.id.go);
		lessonName=(EditText)findViewById(R.id.lessonname);
		go.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				lessonText = lessonName.getText().toString();
				startActivity(new Intent(LessonPlan.this,SaveLesson.class));
				finish();
				
				
			}
		});
	}
}
