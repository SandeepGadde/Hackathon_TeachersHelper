package com.example.teachershelper;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class ShowWeb extends Activity {
	private WebView webview;
    private static final String TAG = "Main";
    private ProgressDialog progressBar = null;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.showweb);
        this.webview = (WebView)findViewById(R.id.webView1);	 
        WebSettings settings = webview.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setPluginsEnabled(true);
        settings.setSupportMultipleWindows(true);
        settings.setSupportZoom(false);
        
        //settings.setAppCacheEnabled(true);
        
        
        webview.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
        webview.setWebChromeClient(new WebChromeClient());
        webview.setAlwaysDrawnWithCacheEnabled(true);
        
        final AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        progressBar = ProgressDialog.show(this, "", "Loading...     ");
        webview.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Log.i(TAG, "Processing webview url click...");	                
                view.loadUrl(url);
                return false;
            }
            
            public void onPageFinished(WebView view, String url) {
            	//Log.d("onPageStarted original",view.getOriginalUrl());
            	Log.d("onPageStarted",url);
                if (progressBar.isShowing()) {
                    progressBar.dismiss();
                }
                
            }
            
            public void onPageStarted(WebView view, String url, Bitmap favicon)
            {
            	//Log.d("onPageStarted original",view.getOriginalUrl());
            	Log.d("onPageStarted",url);
            	if(!progressBar.isShowing())
            		progressBar.show();
            }
            
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {	                	                
                alertDialog.setTitle("Error");
                alertDialog.setMessage(description);
                alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        return;
                    }
                });
                alertDialog.show();
            }
        });        
        webview.loadUrl(ShowListAdapter.selectedURL);
    }
    
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
    	Log.d("Clicked go Back","Clicked go Back");
     if (keyCode == KeyEvent.KEYCODE_BACK){
      if(webview.canGoBack()){
    	  Log.d("Can go Back","Can go Back");
       webview.goBack();
                return true;
      }
     }
     return super.onKeyDown(keyCode, event);
    }
}