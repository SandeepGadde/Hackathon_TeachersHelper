package com.example.teachershelper;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ListView;

public class ShowSavedLessons extends Activity {
	ListView savedLesson;
	ArrayList ar= new ArrayList();
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		
		setContentView(R.layout.showsavedlesson);
		savedLesson = (ListView)findViewById(R.id.list);
		
		DBAdapter db = new DBAdapter(getApplicationContext());
		db.open();
		ar = (ArrayList) db.getLessonList();
		Log.d("DB Lesson SIze:",String.valueOf(ar.size()));
		db.close();
		//ar.add("asdas");
		//ar.add("werwe");
		
		ShowSavedLessonAdapter se= new ShowSavedLessonAdapter(this,android.R.layout.simple_list_item_1,android.R.id.text1,ar);
		savedLesson.setAdapter(se);
	}
}
