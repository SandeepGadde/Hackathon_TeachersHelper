package com.example.teachershelper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Random;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

//In Main Activity you can use:    DBAdapter db = new DBAdapter( this );     which allows db.method commands from here.
public class DBAdapter
{
    int id = 0;

    

    private static final String TAG = "DBAdapter";

    private static final String DATABASE_NAME = "Lesson_DB";

    private static final String Table_Lesson = "Lesson";

    private static final String Table_Content = "Content";

    private static final int DATABASE_VERSION = 1;
    
    public static final String KEY_CONTENTNAME = "Content_Name";

    public static final String KEY_CONTENTURL = "Content_URL";
    
    //public static final String KEY_LESSONID = "Lesson_ID";

    public static final String KEY_LESSONNAME = "Lesson_Name";

    public static final String KEY_LESSONDATE = "Lesson_Date";
    
    public static final String KEY_LESSONDESCRIPTION = "Lesson_Description";

    private static final String TABLE_CONTENT_CREATE = "CREATE TABLE " + Table_Content
                    + " (" + KEY_LESSONNAME + " TEXT , " + KEY_CONTENTNAME
                    + " TEXT, " + KEY_CONTENTURL + " TEXT" +
                    ")";

    private static final String TABLE_LESSON_CREATE = "CREATE TABLE " + Table_Lesson
                    + " (" + KEY_LESSONNAME + " TEXT, " + KEY_LESSONDATE + " Date , " + KEY_LESSONDESCRIPTION + " TEXT" + ")";



    private final Context context;

    private DatabaseHelper DBHelper;

    private SQLiteDatabase db;


    public DBAdapter( Context ctx )
    {
        this.context = ctx;
        DBHelper = new DatabaseHelper( context );
    }


    private static class DatabaseHelper extends SQLiteOpenHelper
    {
        DatabaseHelper( Context context )
        {
            super( context, DATABASE_NAME, null, DATABASE_VERSION );
        }


        @Override
        public void onCreate( SQLiteDatabase db )
        {
            db.execSQL( TABLE_LESSON_CREATE );
            Log.d("Lesson Create",TABLE_LESSON_CREATE);
            db.execSQL( TABLE_CONTENT_CREATE );
            Log.d("Lesson Create",TABLE_CONTENT_CREATE);
        }


        @Override
        public void onUpgrade( SQLiteDatabase db, int oldVersion, int newVersion )
        {
            Log.w( TAG, "Upgrading database from version " + oldVersion
                + " to " + newVersion + ", which will destroy all old data" );
            db.execSQL( "DROP TABLE IF EXISTS Lesson" );
            db.execSQL( "DROP TABLE IF EXISTS Content" );
            onCreate( db );
        }
    }


 // ---opens the database---
    public DBAdapter open() throws SQLException
    {
        db = DBHelper.getWritableDatabase();
        return this;
    }


    // ---closes the database---
    public boolean close()
    {
        DBHelper.close();
        if ( db.isOpen() )
        {
            return false;
        }
        return true;
    }


 // ---insert a Lesson into the database--- Parameter is the Lessons Name
    public long insertLesson( String lessonName, String lessonDescription )
    {
        ContentValues initialValues = new ContentValues();
        initialValues.put( KEY_LESSONNAME, lessonName.toString() );

        DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        Date date = new Date();
        initialValues.put( KEY_LESSONDATE, (dateFormat.format(date)).toString() );
        initialValues.put( KEY_LESSONDESCRIPTION, lessonDescription.toString() );
        return db.insert( Table_Lesson, null, initialValues );
    }


 // Returns int number of Lessons in DB (Count)
    public int getAllEntries()
    {
        Cursor cursor = db.rawQuery( "SELECT COUNT(Lesson_Name) FROM Lesson", null );
        if ( cursor.moveToFirst() )
        {
            return cursor.getInt( 0 );
        }
        return cursor.getInt( 0 );

    }


  //Returns an ArrayList of Lesson Names
    public List<String> getLessonList()
    {
        List<String> strs = new ArrayList<String>();
        Cursor cursor = db.rawQuery( "SELECT Lesson_Name, Lesson_Name FROM Lesson" ,
            null );
        if ( cursor == null )
        {
            return strs;
        }
        if ( cursor.moveToFirst() )
        {
            strs.add( cursor.getString( 1 ) );
            while ( cursor.moveToNext() )
            {
                strs.add( cursor.getString( 1 ) );

            }
            Collections.sort( strs );
        }
        return strs;
    }


  //---insert Content into the database--- Parameters are the Lesson_Name(Foreign Key - From Lesson), the Content_Name, and the Content_URL
    public long insertContent(String lessonName, String contentName, String contentURL )
    {
        ContentValues initialValues = new ContentValues();
        initialValues.put( KEY_LESSONNAME, lessonName.toString() );
        initialValues.put( KEY_CONTENTNAME, contentName.toString() );
        initialValues.put( KEY_CONTENTURL, contentURL.toString() );
        return db.insert( Table_Content, null, initialValues );
    }


  //Returns an ArrayList of Content Names
    public List<String> getContentList( String lessonName )
    {
        List<String> strs = new ArrayList<String>();
        
        String[] lessonNameAry = new String[1];
        lessonNameAry[0] = lessonName;
        
        Cursor cursor = db.rawQuery("SELECT Content_Name, Content_Name FROM Content WHERE Lesson_Name =?",lessonNameAry);
        
        if ( cursor == null )
        {
            return strs;
        }
        if ( cursor.moveToFirst() )
        {
            strs.add( cursor.getString( 1 ) );
            while ( cursor.moveToNext() )
            {
                strs.add( cursor.getString( 1 ) );

            }
            Collections.sort( strs );
        }
        return strs;
    }



 // Returns int total content names stored in DB (Count)
    public int getAllContentEntries()
    {
        Cursor cursor = db.rawQuery( "SELECT COUNT(Content_Name) FROM Content",
            null );
        if ( cursor.moveToFirst() )
        {
            return cursor.getInt( 0 );
        }
        return cursor.getInt( 0 );

    }
    
    public List<String> getLessonInfo (String lessonName)
    {
        List<String> strs = new ArrayList<String>();
        
        String[] lessonNameAry = new String[1];
        lessonNameAry[0] = lessonName;
        
        Cursor cursor = db.rawQuery("SELECT Lesson_Date, Lesson_Description FROM Lesson WHERE Lesson_Name =?",lessonNameAry);
        
        if ( cursor == null )
        {
            return strs;
        }
        if ( cursor.moveToFirst() )
        {
            strs.add( cursor.getString( 0 ) );
            strs.add( cursor.getString( 1 ) );
        }
        return strs;
    }
}
