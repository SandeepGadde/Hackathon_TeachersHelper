package com.example.teachershelper;


import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.UnknownHostException;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;


import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

public class StartAsyncTask extends AsyncTask<String, Void, String>{
	ProgressDialog mProgressDialog;
	String response  = "";
	ArrayList<SearchHelper> sh = new ArrayList<SearchHelper>();
	ArrayList<SearchHelper> shgoogle = new ArrayList<SearchHelper>();
	ArrayList<SearchHelper> shyoutube = new ArrayList<SearchHelper>();
	@Override
	protected void onPreExecute() {
		mProgressDialog = ProgressDialog.show(MainActivity.ctx,"Please wait..","..while we fetch results!!");
	}
	@Override
	protected void onPostExecute(String result) {
		if(!result.equals("UnKnownHost"))
		{
			if(MainActivity.setting[0]==1)
				parseJSON(result);
			Log.d("After parse","yes");
			MainActivity.showResults(sh,shgoogle,shyoutube);
		}
		mProgressDialog.dismiss();
	}
	@Override
	protected String doInBackground(String... params) {
		// TODO Auto-generated method stub
		String response = "",response1="",response2="";
		for (String url : params) {
			if(MainActivity.setting[0]==1)
			{
				HttpURLConnection urlConnection = null;			
				Log.d("Raw url:",url);
				Log.d("bg work"," started");
				DefaultHttpClient client = new DefaultHttpClient();
				HttpGet httpGet = new HttpGet(url);
				try {				
					HttpResponse execute = client.execute(httpGet);
					
					if(String.valueOf(execute.getStatusLine()).contains("200"))
					{
						response = convertStreamToString(execute.getEntity().getContent());
						Log.d("I got something",response);
					}    				
				} catch (UnknownHostException e) {
					response = "UnKnownHost";
					Log.d("IN1",e.getMessage());
				} catch (ConnectException e) {
					response = "UnKnownHost";
					Log.d("IN2",e.getMessage());
				} catch (IllegalStateException e) {
					// TODO Auto-generated catch block
					response = "UnKnownHost";
					Log.d("IN3",e.getMessage());
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					response = "UnKnownHost";
					Log.d("IN4",e.getMessage());
					e.printStackTrace();
				}
			}
			if(MainActivity.setting[1]==1)
			{
				//Second Call
				HttpURLConnection urlConnection1 = null;	
				DefaultHttpClient client1 = new DefaultHttpClient();
				HttpGet httpGet1 = new HttpGet("https://ajax.googleapis.com/ajax/services/search/web?v=1.0&q="+MainActivity.keyword);
				try {				
					HttpResponse execute1 = client1.execute(httpGet1);
					
					if(String.valueOf(execute1.getStatusLine()).contains("200"))
					{
						response1 = parseGoogle(convertStreamToString(execute1.getEntity().getContent()));
						Log.d("I got something",response1);
					}    				
				} catch (UnknownHostException e) {
					response1 = "UnKnownHost";
					Log.d("IN1",e.getMessage());
				} catch (ConnectException e) {
					response1 = "UnKnownHost";
					Log.d("IN2",e.getMessage());
				} catch (IllegalStateException e) {
					// TODO Auto-generated catch block
					response1 = "UnKnownHost";
					Log.d("IN3",e.getMessage());
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					response1 = "UnKnownHost";
					Log.d("IN4",e.getMessage());
					e.printStackTrace();
				}
			}
			if(MainActivity.setting[2]==1)
			{
				//Second Call
				HttpURLConnection urlConnection2 = null;	
				DefaultHttpClient client2 = new DefaultHttpClient();
				HttpGet httpGet2 = new HttpGet("https://gdata.youtube.com/feeds/api/videos?v=2&alt=jsonc&q="+MainActivity.keyword);
				try {				
					HttpResponse execute2 = client2.execute(httpGet2);
					
					if(String.valueOf(execute2.getStatusLine()).contains("200"))
					{
						response2 = parseYouTube(convertStreamToString(execute2.getEntity().getContent()));
						Log.d("I got something in 2",response2);
					}    				
				} catch (UnknownHostException e) {
					response2 = "UnKnownHost";
					Log.d("IN1",e.getMessage());
				} catch (ConnectException e) {
					response2 = "UnKnownHost";
					Log.d("IN2",e.getMessage());
				} catch (IllegalStateException e) {
					// TODO Auto-generated catch block
					response2 = "UnKnownHost";
					Log.d("IN3",e.getMessage());
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					response2 = "UnKnownHost";
					Log.d("IN4",e.getMessage());
					e.printStackTrace();
				}
			}
		}
		//https://ajax.googleapis.com/ajax/services/search/web?v=1.0&q=
		Log.d("return resp",response);
		return response;
	}   
	protected String parseGoogle(String result)
	{
		org.json.JSONObject json=null;
    	try {
			json = new JSONObject(result.toString());
			org.json.JSONObject queryArray=json.getJSONObject("responseData");
		    	
	    	org.json.JSONArray itemsArray=queryArray.getJSONArray("results");

	    	for(int i=0;i<itemsArray.length();i++)
	    	{
	    		SearchHelper shhgoogle = new SearchHelper();
	    		org.json.JSONObject newJSONObj=itemsArray.getJSONObject(i);
	    		shhgoogle.setDocId("");
	    		shhgoogle.setDocTitle(newJSONObj.getString("titleNoFormatting"));
	    		shhgoogle.setDocURL(newJSONObj.getString("url"));
	    		Log.d("Title ::",newJSONObj.getString("titleNoFormatting"));
	    		Log.d("Link ::",newJSONObj.getString("url"));
	    		shgoogle.add(shhgoogle);
	    	}
	    	return "ok";
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}
    	
	}
	protected void parseJSON(String result)
	{		
		try {
			JSONObject myobj = new JSONObject(result);
			JSONArray json_Arr = myobj.getJSONArray("documents");
			
			for(int i=0;i<json_Arr.length();i++)
			{
				SearchHelper shh = new SearchHelper();
				Log.d("Doc ID",(json_Arr.getJSONObject(i)).getString("doc_ID"));
				JSONObject json_Obj = (json_Arr.getJSONObject(i)).getJSONObject("resource_data_description");
				//JSONArray json_Arr1 = json_Obj.getJSONArray("")
				//for(int j=0;j<json_Arr1.length();j++)
				Log.d("Doc URL",(json_Obj).getString("resource_locator"));
				shh.setDocId((json_Arr.getJSONObject(i)).getString("doc_ID"));
				shh.setDocURL((json_Obj).getString("resource_locator"));
				String title = (json_Obj).getString("resource_data");
				try{
				Log.d("Title",title.substring(title.indexOf("<dc:title>")+10,title.indexOf("</dc:title>")));
				title = title.substring(title.indexOf("<dc:title>")+10,title.indexOf("</dc:title>"));
				}catch(Exception e){
				Log.d("Title",(json_Obj).getString("resource_locator"));
				title = (json_Obj).getString("resource_locator");
				}
				shh.setDocTitle(title);
				sh.add(shh);
				/*String xml = (json_Obj).getString("resource_data");
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();				
	            DocumentBuilder db;
	            Document dc;
	            try {
	            	db = dbf.newDocumentBuilder();
				 dc = db.parse(new ByteArrayInputStream(xml.getBytes()));
				 dc.getDocumentElement ().normalize ();
				 Log.d("titleval",dc.getElementsByTagName("dc:title").item(0).getChildNodes().item(0).getNodeValue());
						 
				 
				
				} catch (SAXException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ParserConfigurationException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				*/
				/*
				 * DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();				
	            DocumentBuilder db = dbf.newDocumentBuilder();		            
	            Document doc = db.parse("http://www.carloan.com/finance/informa/api/?aid=test12&state="+stateVal+"&fico="+fico.getSelectedItem().toString().split("~")[1].trim());
	            doc.getDocumentElement ().normalize ();
	            //Log.d("Root Element",doc.getDocumentElement().getNodeName());
	            NodeList nl = doc.getElementsByTagName("row");
	            //Log.d("NL Length:",String.valueOf(nl.getLength()));
	            data = new String[nl.getLength()];
	            for(int i =0;i<nl.getLength();i++)
	            {
	            	Node nNode = nl.item(i);
	            	if (nNode.getNodeType() == Node.ELEMENT_NODE) {	      
	     		      Element eElement = (Element) nNode;	   
	     		      data[i] = eElement.getElementsByTagName("description").item(0).getChildNodes().item(0).getNodeValue() +"\n"
	     		    		  + "Rate: "+eElement.getElementsByTagName("rate").item(0).getChildNodes().item(0).getNodeValue();
	     		     // System.out.println("desc : " + eElement.getElementsByTagName("description").item(0).getChildNodes().item(0).getNodeValue());
	     		     // System.out.println("rate : " + eElement.getElementsByTagName("rate").item(0).getChildNodes().item(0).getNodeValue());	      
	     		     // System.out.println("The Data:"+data[i]);
	            	}
	            }
				 */
			}	
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			Log.d("Exception",e.getMessage());
			//Toast.makeText(MainActivity.ctx, "Parse Error!!",Toast.LENGTH_LONG).show();
		} 		
	}
	@SuppressLint("NewApi")
	protected String parseYouTube(String results)
	{
		
		JSONObject json;
		try {
			json = new JSONObject(results);
			org.json.JSONObject queryArray=json.getJSONObject("data");
			   org.json.JSONArray itemsArray=queryArray.getJSONArray("items");

			   for(int i=0;i<itemsArray.length();i++)
			   {
				   SearchHelper shhyoutube = new SearchHelper();
				   org.json.JSONObject newJSONObj=itemsArray.getJSONObject(i);
				   System.out.println("Title ::"+newJSONObj.getString("title"));
				   
				   shhyoutube.setDocId(null);
				   shhyoutube.setDocTitle(newJSONObj.getString("title"));
				   if(newJSONObj.getJSONObject("content").has("5"))
				   {
					   shhyoutube.setDocURL(newJSONObj.getJSONObject("content").getString("5"));
					   System.out.println("Link ::"+newJSONObj.getJSONObject("content").getString("5"));
					   shyoutube.add(shhyoutube);
				   }
				   else
					   continue;
				   
			   }
			   return "true";
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.getMessage();
		}

	}
	protected String convertStreamToString(InputStream is) 
	    {
	    	BufferedReader in = new BufferedReader(new InputStreamReader(is));
	    	String inputLine,resp="";
	    	try {
	    		while ((inputLine = in.readLine()) != null) 
	    		{
	    			//System.out.println(inputLine);
	    			resp += inputLine;
	    		}
	    	} catch (IOException e) {
	    		// TODO Auto-generated catch block
	    		e.printStackTrace();
	    	}
	    	return resp;
	    }
}
