package com.example.teachershelper;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;
public class Settings extends Activity {
	Button save;
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.settings);
		save = (Button)findViewById(R.id.save);
		if(MainActivity.setting[0]==1)
			((CheckBox)findViewById(R.id.lr)).setChecked(true);
		if(MainActivity.setting[1]==1)
			((CheckBox)findViewById(R.id.google)).setChecked(true);
		if(MainActivity.setting[2]==1)
			((CheckBox)findViewById(R.id.youtube)).setChecked(true);
		
		save.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				if(((CheckBox)findViewById(R.id.youtube)).isChecked())
					MainActivity.setting[2] = 1;
				else
					MainActivity.setting[2] = 0;
				
				if(((CheckBox)findViewById(R.id.google)).isChecked())
					MainActivity.setting[1] = 1;
				else
					MainActivity.setting[1] = 0;
				if(((CheckBox)findViewById(R.id.lr)).isChecked())
					MainActivity.setting[0] = 1;
				else
					MainActivity.setting[0] = 0;
				Log.d("Setting Values",String.valueOf(MainActivity.setting[0]+"|"+MainActivity.setting[1]+"|"+MainActivity.setting[2]));	
				if(MainActivity.setting[0] == 0 && MainActivity.setting[1] == 0 && MainActivity.setting[2] == 0)
					Toast.makeText(Settings.this, "Please select atleast one", Toast.LENGTH_LONG).show();
				else
					finish();
			}
		});
	}
}
